
public class Main {
    public static void main(String[] args) {

        Calculadora calc = new Calculadora();
        calc.numA = 5;
        calc.numB = 4;

        System.out.println("Soma: "+ calc.soma());
        System.out.println("Subtração: "+ calc.sub());
        System.out.println("Divisão: "+ calc.div());
        System.out.println("Multiplicação: "+ calc.mult());
        System.out.println("0: "+ calc.verificarPrimo(0));
        System.out.println("1: "+ calc.verificarPrimo(1));

    }
}