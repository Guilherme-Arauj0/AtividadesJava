

public class Calculadora {

    int numA;
    int numB;
    int soma(){
        return numA + numB;
    }

    int sub(){
        return numA - numB;
    }

    double div(){
        return (double) numA / numB;
    }

    int mult(){
        return numA * numB;
    }

    boolean verificarPrimo(int n){

        if(n <= 1){
            return false;
        } else if((n != 2) && (n % 2 == 0)){
            return false;
        }

        for(int i = 3; i< n; i+=2){
            if(n % i == 0){
                return false;
            }
        }

        return true;
    }
}
